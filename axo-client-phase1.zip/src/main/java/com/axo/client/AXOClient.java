package com.axo.client;

import com.axo.client.config.ConfigManager;
import com.axo.client.gui.MainScreen;
import com.axo.client.modules.ModuleManager;
import com.axo.client.modules.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AXOClient implements ClientModInitializer {
    public static final String ID = "axoclient";
    public static final Logger LOG = LoggerFactory.getLogger("AXO CLIENT");
    private static KeyMapping openMenu;

    @Override public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();

        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(ID, "main"));
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.axoclient.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, cat));

        HudRenderCallback.EVENT.register((graphics, delta) -> HudRenderer.render(graphics));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openMenu.consumeClick()) {
                if (mc.screen == null) mc.setScreen(new MainScreen(null));
            }
        });

        // Touch-friendly entry point: a button on the title screen.
        ScreenEvents.AFTER_INIT.register((mc, screen, w, h) -> {
            if (screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(Button.builder(Component.literal("AXO"),
                        b -> mc.setScreen(new MainScreen(screen))).bounds(4, 4, 50, 20).build());
            }
        });
        LOG.info("AXO CLIENT loaded: {} modules", ModuleManager.all().size());
    }
}
