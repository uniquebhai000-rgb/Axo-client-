package com.axo.client.modules;

public enum ModuleCategory { HUD, PVP, PERFORMANCE, VISUAL, WORLD, UTILITY }
