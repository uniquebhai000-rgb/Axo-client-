package com.axo.client.modules.hud;

import com.axo.client.AXOClient;
import com.axo.client.modules.Module;
import com.axo.client.modules.ModuleManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class HudRenderer {
    private HudRenderer() {}

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        for (Module m : ModuleManager.all()) {
            if (!m.enabled || !(m instanceof HudModule h)) continue;
            try {
                String t = h.getText(mc);
                int w = mc.font.width(t);
                if (h.background) g.fill(h.x - 2, h.y - 2, h.x + w + 2, h.y + 10, 0x90000000);
                g.drawString(mc.font, t, h.x, h.y, h.color);
            } catch (Throwable e) {
                AXOClient.LOG.error("HUD module {} crashed, disabling", h.name, e);
                h.enabled = false;
            }
        }
    }
}
