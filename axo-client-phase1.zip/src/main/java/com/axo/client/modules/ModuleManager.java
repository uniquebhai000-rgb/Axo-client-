package com.axo.client.modules;

import com.axo.client.modules.hud.HudModules;
import java.util.*;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private ModuleManager() {}

    public static void init() {
        MODULES.clear();
        MODULES.addAll(HudModules.create());
    }

    public static List<Module> all() { return Collections.unmodifiableList(MODULES); }
    public static int enabledCount() { return (int) MODULES.stream().filter(m -> m.enabled).count(); }
    public static Module byId(String id) {
        for (Module m : MODULES) if (m.id.equals(id)) return m;
        return null;
    }
    public static void disableAll() { for (Module m : MODULES) m.setEnabled(false); }
}
