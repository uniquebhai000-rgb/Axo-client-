package com.axo.client.modules.hud;

import com.axo.client.modules.Module;
import com.axo.client.modules.ModuleCategory;
import java.util.function.Function;
import net.minecraft.client.Minecraft;

/** A HUD element that draws one line of text. Position/colour/background are per-module settings. */
public class HudModule extends Module {
    public int x = 4, y = 4;
    public int color = 0xFFFFFFFF;
    public boolean background = true;
    private final Function<Minecraft, String> text;

    public HudModule(String id, String name, String desc, Function<Minecraft, String> text) {
        super(id, name, desc, ModuleCategory.HUD);
        this.text = text;
    }

    public String getText(Minecraft mc) { return text.apply(mc); }
}
