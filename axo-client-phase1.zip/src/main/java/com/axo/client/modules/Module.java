package com.axo.client.modules;

import com.axo.client.AXOClient;
import com.axo.client.config.ConfigManager;

/** Base class: every module has its own independent ON/OFF state. */
public abstract class Module {
    public final String id, name, description;
    public final ModuleCategory category;
    public boolean enabled;
    public boolean favorite;

    protected Module(String id, String name, String description, ModuleCategory category) {
        this.id = id; this.name = name; this.description = description; this.category = category;
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) onEnable(); else onDisable();
        } catch (Throwable t) {
            AXOClient.LOG.error("Module {} failed, disabling", name, t);
            enabled = false;
        }
        ConfigManager.save();
    }

    protected void onEnable() {}
    protected void onDisable() {}
}
