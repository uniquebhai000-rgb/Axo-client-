package com.axo.client.modules.hud;

import com.axo.client.modules.Module;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import net.minecraft.client.multiplayer.PlayerInfo;

public final class HudModules {
    private static final long START = System.currentTimeMillis();
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");

    public static List<Module> create() {
        List<HudModule> l = new ArrayList<>();
        l.add(new HudModule("fps", "FPS Counter", "Shows current frames per second.",
                mc -> mc.getFps() + " FPS"));
        l.add(new HudModule("coords", "Coordinates HUD", "Shows your XYZ position.",
                mc -> String.format("XYZ: %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ())));
        l.add(new HudModule("direction", "Direction HUD", "Shows the direction you are facing.",
                mc -> { String n = mc.player.getDirection().getName(); return "Facing: " + Character.toUpperCase(n.charAt(0)) + n.substring(1); }));
        l.add(new HudModule("ping", "Ping Display", "Shows your latency to the server.",
                mc -> {
                    PlayerInfo info = mc.getConnection() == null ? null : mc.getConnection().getPlayerInfo(mc.player.getUUID());
                    return info == null ? "Ping: --" : "Ping: " + info.getLatency() + " ms";
                }));
        l.add(new HudModule("clock", "Clock HUD", "Shows your real-world time.",
                mc -> LocalTime.now().format(CLOCK)));
        l.add(new HudModule("memory", "Memory Usage HUD", "Shows Java memory used / max.",
                mc -> { Runtime r = Runtime.getRuntime(); return "Mem: " + ((r.totalMemory() - r.freeMemory()) >> 20) + "/" + (r.maxMemory() >> 20) + " MB"; }));
        l.add(new HudModule("session", "Session Timer", "Shows how long you have played this session.",
                mc -> { long s = (System.currentTimeMillis() - START) / 1000; return String.format("Session: %02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60); }));
        int y = 4;
        for (HudModule m : l) { m.y = y; y += 14; }
        return new ArrayList<>(l);
    }
}
