package com.axo.client.config;

import com.axo.client.AXOClient;
import com.axo.client.modules.Module;
import com.axo.client.modules.ModuleManager;
import com.axo.client.modules.hud.HudModule;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import net.fabricmc.loader.api.FabricLoader;

/** JSON config. Invalid files are backed up to config.json.bad and defaults are used. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("axoclient").resolve("config.json"); }

    static class State { boolean enabled, favorite, background = true; int x, y, color = 0xFFFFFFFF; }

    public static void save() {
        try {
            Map<String, State> out = new LinkedHashMap<>();
            for (Module m : ModuleManager.all()) {
                State s = new State();
                s.enabled = m.enabled; s.favorite = m.favorite;
                if (m instanceof HudModule h) { s.x = h.x; s.y = h.y; s.color = h.color; s.background = h.background; }
                out.put(m.id, s);
            }
            Files.createDirectories(file().getParent());
            Files.writeString(file(), GSON.toJson(out));
        } catch (IOException e) {
            AXOClient.LOG.error("Could not save config", e);
        }
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) { save(); return; }
        try {
            Map<String, State> in = GSON.fromJson(Files.readString(f), new TypeToken<Map<String, State>>() {}.getType());
            if (in == null) throw new JsonParseException("empty");
            for (Module m : ModuleManager.all()) {
                State s = in.get(m.id);
                if (s == null) continue;
                m.enabled = s.enabled; m.favorite = s.favorite;
                if (m instanceof HudModule h) { h.x = s.x; h.y = s.y; h.color = s.color; h.background = s.background; }
            }
        } catch (Exception e) {
            AXOClient.LOG.error("Invalid config, backing up and resetting", e);
            try { Files.move(f, f.resolveSibling("config.json.bad"), StandardCopyOption.REPLACE_EXISTING); } catch (IOException ignored) {}
            save();
        }
    }
}
