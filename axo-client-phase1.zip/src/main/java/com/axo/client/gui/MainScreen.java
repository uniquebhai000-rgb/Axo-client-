package com.axo.client.gui;

import com.axo.client.modules.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class MainScreen extends Screen {
    static final int PURPLE = 0xFFB026FF, VIOLET = 0xFF8F00FF, GREY = 0xFFAAAAAA;
    private final Screen parent;

    public MainScreen(Screen parent) { super(Component.literal("AXO CLIENT")); this.parent = parent; }

    private static String ver(String id) {
        return FabricLoader.getInstance().getModContainer(id).map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
    }

    @Override protected void init() {
        int cx = width / 2;
        addRenderableWidget(Button.builder(Component.literal("Module Manager"), b -> minecraft.setScreen(new ModuleScreen(this)))
                .bounds(cx - 100, height - 56, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(cx - 100, height - 30, 200, 20).build());
    }

    @Override public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        int cx = width / 2;
        g.drawCenteredString(font, Component.literal("AXO CLIENT"), cx, 14, PURPLE);
        g.drawCenteredString(font, Component.literal("Your Game. Your Rules. Your Client."), cx, 28, VIOLET);
        String[] lines = {
            "Player: " + minecraft.getUser().getName(),
            "Minecraft: " + ver("minecraft") + "   Fabric Loader: " + ver("fabricloader"),
            "FPS: " + minecraft.getFps(),
            "Modules: " + ModuleManager.all().size() + "   Enabled: " + ModuleManager.enabledCount()
        };
        int y = 52;
        for (String s : lines) { g.drawCenteredString(font, Component.literal(s), cx, y, GREY); y += 14; }
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}
