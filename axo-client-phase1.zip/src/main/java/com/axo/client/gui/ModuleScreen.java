package com.axo.client.gui;

import com.axo.client.modules.Module;
import com.axo.client.modules.ModuleManager;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Module Manager: 2 columns x 4 rows per page, each button toggles one module. */
public class ModuleScreen extends Screen {
    private static final int PER_PAGE = 8;
    private final Screen parent;
    private int page = 0;

    public ModuleScreen(Screen parent) { super(Component.literal("Module Manager")); this.parent = parent; }

    private static Component label(Module m) {
        return Component.literal(m.name + ": " + (m.enabled ? "ON" : "OFF"));
    }

    @Override protected void init() {
        List<Module> mods = ModuleManager.all();
        int cx = width / 2, start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < mods.size(); i++) {
            Module m = mods.get(start + i);
            int x = cx - 154 + (i % 2) * 158, y = 36 + (i / 2) * 24;
            addRenderableWidget(Button.builder(label(m), b -> { m.toggle(); b.setMessage(label(m)); })
                    .bounds(x, y, 150, 20).tooltip(Tooltip.create(Component.literal(m.description))).build());
        }
        int by = height - 28;
        Button prev = Button.builder(Component.literal("<"), b -> { page--; rebuildWidgets(); }).bounds(cx - 154, by, 30, 20).build();
        Button next = Button.builder(Component.literal(">"), b -> { page++; rebuildWidgets(); }).bounds(cx - 120, by, 30, 20).build();
        prev.active = page > 0;
        next.active = start + PER_PAGE < mods.size();
        addRenderableWidget(prev); addRenderableWidget(next);
        addRenderableWidget(Button.builder(Component.literal("Disable All"), b -> { ModuleManager.disableAll(); rebuildWidgets(); })
                .bounds(cx - 84, by, 80, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose()).bounds(cx + 4, by, 150, 20).build());
    }

    @Override public void render(GuiGraphics g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        g.drawCenteredString(font, Component.literal("Module Manager  (" + ModuleManager.enabledCount() + " enabled)"), width / 2, 14, MainScreen.PURPLE);
    }

    @Override public void onClose() { minecraft.setScreen(parent); }
}
