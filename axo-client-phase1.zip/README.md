# AXO CLIENT (Phase 1) — Minecraft 1.21.11, Fabric, Java 21

Build with GitHub Actions (no PC needed):
1. Create a free GitHub repo, upload ALL files from this zip (keep the .github folder).
2. Open the Actions tab -> "Build AXO CLIENT" -> wait for green check.
3. Download artifact `axo-client-jar`, unzip, use the jar WITHOUT "-sources".
4. Install Fabric Loader 0.18.4 + Fabric API 0.141.1+1.21.11 for 1.21.11 in PojavLauncher/Mojo,
   put the AXO jar and Fabric API jar in the `mods` folder. Use Java 21.

Open menu: "AXO" button (top-left of title screen) or Right Shift key (bind via on-screen keyboard).
Compatibility: UNTESTED on device. If the build fails, send me the red error log.
